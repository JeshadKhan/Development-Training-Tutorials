/* 
    Document    : Go Top Button
    Created by  : Jeshad Khan
    Author      : Jeshad Khan
    Designation : Software Developer & Web Designer and Developer.
    Dedicated by: Gunjon.
    Powered by  : LumexTech Solution Ltd.
    Description : Purpose of go top button JavaScript.
*/

/***********************************************/
/*		Go Top Button		*/
/***********************************************/

$(document).ready(function(){
	// show or hide the sticky footer go-top button
	$(window).scroll(function(){
		if($(this).scrollTop() > 20){
			$('.back-to-top').fadeIn(500);
		}
		else{
			$('.back-to-top').fadeOut(700);
		}
	});
	// animate the scroll to top
	$('.back-to-top').click(function(event){
		event.preventDefault();
		$('html, body').animate({scrollTop: 0}, 800);
	})
});